IBTrACS: Tropical cyclone best track data
Source: http://www.ncdc.noaa.gov/ibtracs/index.php?name=wmo-data
